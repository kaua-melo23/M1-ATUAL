import sqlite3
import os

DB_PATH = os.path.join('database', 'lanchonete.db')

def atualizar_tabela():
    if not os.path.exists(DB_PATH):
        print("❌ Banco de dados não encontrado. Rode a aplicação primeiro.")
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Lista de colunas novas que queremos garantir que existam
    colunas_novas = [
        ("endereco", "TEXT DEFAULT 'Retirada no Local'"),
        ("bairro", "TEXT DEFAULT ''"),
        ("taxa_entrega", "REAL DEFAULT 0")
    ]

    for nome_coluna, tipo_coluna in colunas_novas:
        try:
            # Tenta adicionar a coluna
            cursor.execute(f"ALTER TABLE pedidos ADD COLUMN {nome_coluna} {tipo_coluna}")
            print(f"✅ Coluna '{nome_coluna}' adicionada com sucesso.")
        except sqlite3.OperationalError:
            # Se cair aqui, é porque a coluna já existe
            print(f"ℹ️ Coluna '{nome_coluna}' já existe, pulando...")

    conn.commit()
    conn.close()
    print("\n🚀 Base de dados atualizada e pronta para o novo Painel de Pedidos!")

if __name__ == "__main__":
    atualizar_tabela()