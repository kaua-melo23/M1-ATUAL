import os
import mercadopago
from flask import Blueprint, request, jsonify
from datetime import datetime, timedelta
from dotenv import load_dotenv

# Importamos as funções do seu database.py
from database import (
    registrar_pedido_completo, 
    conectar, 
    atualizar_status_pedido, 
    baixar_estoque_por_produto
)

load_dotenv()

vendas_bp = Blueprint('vendas_bp', __name__)

# Configuração Mercado Pago
ACCESS_TOKEN = os.getenv("MP_ACCESS_TOKEN")
sdk = mercadopago.SDK(ACCESS_TOKEN)

# --- FUNÇÃO AUXILIAR DE NOTIFICAÇÃO ---

def enviar_pedido_whatsapp(pedido_id):
    """
    Busca os detalhes do pedido e gera o resumo para o WhatsApp (Log/Simulado).
    """
    try:
        conn = conectar()
        pedido = conn.execute('SELECT * FROM pedidos WHERE id = ?', (pedido_id,)).fetchone()
        itens = conn.execute('SELECT * FROM itens_pedido WHERE pedido_id = ?', (pedido_id,)).fetchall()
        conn.close()

        if pedido:
            resumo_itens = "\n".join([f"- {i['quantidade']}x {i['produto_nome']}" for i in itens])
            mensagem = (
                f"🔔 *NOVO PEDIDO #{pedido_id}*\n\n"
                f"👤 *Cliente:* {pedido['cliente_nome']}\n"
                f"📍 *Endereço:* {pedido['endereco']}\n"
                f"💳 *Método:* PIX (PAGO)\n"
                f"--------------------------\n"
                f"🛒 *Itens:*\n{resumo_itens}\n"
                f"--------------------------\n"
                f"💰 *Total:* R$ {pedido['total_geral']:.2f}\n"
                f"🆔 *Cód. Pedido:* #{pedido_id}"
            )
            print("\n=== DISPARO WHATSAPP ===\n", mensagem)
    except Exception as e:
        print(f"Erro WhatsApp: {e}")

# --- ROTAS ---

@vendas_bp.route('/api/pagamento/gerar_pix', methods=['POST'])
def gerar_pix_temporario():
    """
    Gera o PIX com validade de 4 minutos. 
    O pedido AINDA NÃO é salvo no banco de dados aqui para evitar 'pedidos fantasmas'.
    """
    try:
        dados = request.get_json()
        total = float(dados.get('total', 0))

        # Define expiração para 4 minutos no formato aceito pelo MP
        # Ajustado para o fuso horário local (-03:00)
        expiracao = (datetime.now() + timedelta(minutes=4)).strftime("%Y-%m-%dT%H:%M:%S.000-03:00")

        payment_data = {
            "transaction_amount": total,
            "description": "Pagamento Lanchonete (Expira em 4min)",
            "payment_method_id": "pix",
            "date_of_expiration": expiracao, # Trava de 4 minutos
            "payer": {
                "email": "cliente@email.com",
                "first_name": "Cliente",
                "identification": { "type": "CPF", "number": "12345678909" }
            },
            # Guardamos os dados do carrinho no METADATA para recuperar no Webhook
            "metadata": {
                "dados_pedido": dados  
            }
        }

        payment_response = sdk.payment().create(payment_data)
        payment = payment_response["response"]

        if "point_of_interaction" not in payment:
            return jsonify({"error": "Erro ao gerar PIX", "detalhes": payment}), 400

        return jsonify({
            "status": "pending",
            "id_mp": payment["id"],
            "pix_copia_cola": payment["point_of_interaction"]["transaction_data"]["qr_code"],
            "qr_code_img": payment["point_of_interaction"]["transaction_data"]["qr_code_base64"],
            "expires_at": expiracao
        })

    except Exception as e:
        print(f"Erro ao gerar PIX: {e}")
        return jsonify({"error": str(e)}), 500

@vendas_bp.route('/api/webhook', methods=['POST'])
def webhook():
    """
    O pedido SÓ É REGISTRADO no banco se o pagamento for aprovado.
    """
    try:
        # Pega o ID do pagamento enviado pelo MP
        id_recurso = request.args.get('data.id') or request.get_json().get('data', {}).get('id')
        
        if id_recurso:
            payment_info = sdk.payment().get(id_recurso)
            status_mp = payment_info["response"].get("status")
            
            # Se o status for 'approved', transformamos o pagamento em pedido no banco
            if status_mp == "approved":
                # Recuperamos os dados do carrinho que salvamos no metadata
                dados_originais = payment_info["response"].get("metadata", {}).get("dados_pedido")
                
                if dados_originais:
                    # Organiza os dados para a função de banco de dados
                    dados_pedido = {
                        'nome': dados_originais.get('nome_cliente') or dados_originais.get('cliente_nome') or "Cliente",
                        'bairro': dados_originais.get('bairro', ''),
                        'endereco': dados_originais.get('endereco', 'Retirada'),
                        'total_itens': float(dados_originais.get('total_produtos', 0)),
                        'taxa': float(dados_originais.get('taxa_entrega', 0)),
                        'total_geral': float(dados_originais.get('total', 0)),
                        'metodo': 'PIX'
                    }
                    itens_list = dados_originais.get('itens_detalhados', [])

                    conn = conectar()
                    # Verifica se este pagamento já foi processado (segurança)
                    ja_existe = conn.execute('SELECT id FROM pedidos WHERE id_pagamento_mp = ?', 
                                            (str(id_recurso),)).fetchone()
                    
                    if not ja_existe:
                        # 1. REGISTRA O PEDIDO NO SQLITE SOMENTE AGORA
                        pedido_id = registrar_pedido_completo(dados_pedido, itens_list)
                        
                        if pedido_id:
                            # 2. Vincula o ID do MP ao pedido
                            conn.execute('UPDATE pedidos SET id_pagamento_mp = ? WHERE id = ?', 
                                        (str(id_recurso), pedido_id))
                            conn.commit()

                            # 3. Baixa estoque
                            for item in itens_list:
                                baixar_estoque_por_produto(item['nome'], item['quantidade'])
                            
                            # 4. Finaliza status e avisa WhatsApp
                            atualizar_status_pedido(pedido_id, 'Pago')
                            enviar_pedido_whatsapp(pedido_id)
                            print(f"✅ Pedido #{pedido_id} criado e aprovado via PIX.")
                    
                    conn.close()

    except Exception as e:
        print(f"Erro no Webhook: {e}")
            
    return jsonify({"status": "ok"}), 200

@vendas_bp.route('/api/pedidos/presencial', methods=['POST'])
def pedido_presencial():
    """
    Rota para pagamentos em Dinheiro ou Cartão (registra na hora).
    """
    try:
        dados = request.get_json()
        
        dados_pedido = {
            'nome': dados.get('nome_cliente') or "Cliente",
            'bairro': dados.get('bairro', ''),
            'endereco': dados.get('endereco', 'Retirada'),
            'total_itens': float(dados.get('total_produtos', 0)),
            'taxa': float(dados.get('taxa_entrega', 0)),
            'total_geral': float(dados.get('total', 0)),
            'metodo': dados.get('metodo', 'DINHEIRO').upper()
        }
        itens_list = dados.get('itens_detalhados', [])

        pedido_id = registrar_pedido_completo(dados_pedido, itens_list)
        
        if pedido_id:
            for item in itens_list:
                baixar_estoque_por_produto(item['nome'], item['quantidade'])
            
            atualizar_status_pedido(pedido_id, 'Confirmado')
            enviar_pedido_whatsapp(pedido_id)
            
            return jsonify({"status": "success", "id": pedido_id})
        
        return jsonify({"error": "Erro ao salvar pedido"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@vendas_bp.route('/api/pagamento/status/<id_mp>')
def checar_status_pix(id_mp):
    """
    O frontend chama esta rota para saber se o PIX foi pago e se o pedido já foi criado.
    """
    try:
        conn = conectar()
        pedido = conn.execute('SELECT id, status FROM pedidos WHERE id_pagamento_mp = ?', (str(id_mp),)).fetchone()
        conn.close()
        
        if pedido:
            return jsonify({"pago": True, "pedido_id": pedido['id'], "status": pedido['status']})
        
        return jsonify({"pago": False})
    except Exception as e:
        return jsonify({"error": str(e)}), 500