import os
from flask import Blueprint, request, jsonify, session, render_template, redirect, url_for
from werkzeug.utils import secure_filename
from database import (
    carregar_dados, salvar_dados, carregar_taxas, salvar_taxa, 
    atualizar_status_pedido, conectar, listar_pedidos_formatados,
    deletar_taxa_db, listar_insumos_db, registrar_entrada_lote, 
    transformar_insumos_db, carregar_configuracoes, salvar_configuracoes,
    listar_categorias, listar_categorias_ativas, salvar_categoria,
    atualizar_categoria, deletar_categoria, reordenar_categorias,
    listar_menu_admin, listar_menu_admin_visivel,
    atualizar_item_menu, reordenar_menu_admin,
    adicionar_produto, atualizar_produto, deletar_produto,
    criar_insumo, atualizar_insumo, deletar_insumo, listar_lotes_insumo,
    salvar_receita, listar_receita, fabricar_lote,
    salvar_produto_insumos, listar_produto_insumos, listar_alertas_estoque
)

admin_bp = Blueprint('admin_bp', __name__)
UPLOAD_FOLDER = 'static/uploads'

# --- HELPER: Decorador para proteger as rotas ---
def login_required(f):
    def wrap(*args, **kwargs):
        if not session.get('logado'):
            # Se for chamada de API (fetch/XHR), retorna 401 JSON em vez de redirect
            if request.path.startswith('/api/') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'erro': 'nao_autenticado', 'redirect': '/login'}), 401
            return redirect('/login')
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

# --- DIAGNÓSTICO ---
@admin_bp.route('/admin/diagnostico')
@login_required
def diagnostico():
    from database import conectar
    conn = conectar()
    cur = conn.cursor()
    pedidos = cur.execute('SELECT id, cliente_nome, status, data_hora, total_geral FROM pedidos ORDER BY id DESC LIMIT 10').fetchall()
    itens_count = cur.execute('SELECT COUNT(*) FROM itens_pedido').fetchone()[0]
    conn.close()
    rows = [dict(p) for p in pedidos]
    return jsonify({
        'total_pedidos': len(rows),
        'total_itens_no_banco': itens_count,
        'sessao_ativa': bool(session.get('logado')),
        'ultimos_pedidos': rows
    })

# --- ROTAS DE PÁGINAS ---

@admin_bp.route('/admin')
@login_required
def dashboard():
    return render_template('admin/dashboard.html')

@admin_bp.route('/admin/produtos')
@login_required
def admin_produtos():
    return render_template('admin/produtos.html')

@admin_bp.route('/admin/pedidos')
@login_required
def admin_pedidos():
    return render_template('admin/pedidos.html')

@admin_bp.route('/admin/diagnostico-pedidos')
@login_required
def admin_diagnostico():
    return render_template('admin/diagnostico.html')

@admin_bp.route('/admin/taxas')
@login_required
def admin_taxas():
    return render_template('admin/taxas.html')

@admin_bp.route('/admin/estoque')
@login_required
def admin_estoque():
    """Página de gestão de insumos e estoque"""
    return render_template('admin/estoque.html')

@admin_bp.route('/admin/aparencia')
@login_required
def admin_aparencia():
    """Página de personalização visual da loja"""
    configs = carregar_configuracoes()
    return render_template('admin/aparencia.html', configs=configs)

@admin_bp.route('/api/configuracoes', methods=['GET'])
def api_get_configuracoes():
    return jsonify(carregar_configuracoes())

@admin_bp.route('/api/configuracoes', methods=['POST'])
@login_required
def api_salvar_configuracoes():
    dados = request.get_json()
    campos_permitidos = {'nome_lanchonete', 'slogan', 'cor_primaria', 'cor_texto_header', 'logo_url', 'hora_abertura', 'hora_fechamento'}
    dados_filtrados = {k: v for k, v in dados.items() if k in campos_permitidos}
    salvar_configuracoes(dados_filtrados)
    return jsonify({'status': 'sucesso'})

# --- PÁGINA E APIs DE NAVEGAÇÃO ---

@admin_bp.route('/admin/navegacao')
@login_required
def admin_navegacao():
    return render_template('admin/navegacao.html',
                           categorias=listar_categorias(),
                           menu_admin=listar_menu_admin())

# Categorias do cliente
@admin_bp.route('/api/categorias', methods=['GET'])
def api_listar_categorias():
    return jsonify(listar_categorias())

@admin_bp.route('/api/categorias', methods=['POST'])
@login_required
def api_criar_categoria():
    dados = request.get_json()
    salvar_categoria(dados.get('nome',''), dados.get('emoji','🍽️'))
    return jsonify({'status': 'sucesso'})

@admin_bp.route('/api/categorias/<int:cat_id>', methods=['PUT'])
@login_required
def api_atualizar_categoria(cat_id):
    dados = request.get_json()
    atualizar_categoria(cat_id, dados.get('nome',''), dados.get('emoji','🍽️'), dados.get('ativo', 1))
    return jsonify({'status': 'sucesso'})

@admin_bp.route('/api/categorias/<int:cat_id>', methods=['DELETE'])
@login_required
def api_deletar_categoria(cat_id):
    deletar_categoria(cat_id)
    return jsonify({'status': 'sucesso'})

@admin_bp.route('/api/categorias/reordenar', methods=['POST'])
@login_required
def api_reordenar_categorias():
    dados = request.get_json()
    reordenar_categorias(dados.get('ids', []))
    return jsonify({'status': 'sucesso'})

# Menu admin
@admin_bp.route('/api/menu-admin', methods=['GET'])
@login_required
def api_listar_menu_admin():
    return jsonify(listar_menu_admin())

@admin_bp.route('/api/menu-admin/<int:item_id>', methods=['PUT'])
@login_required
def api_atualizar_item_menu(item_id):
    dados = request.get_json()
    atualizar_item_menu(item_id, dados.get('label',''), dados.get('emoji','📄'), dados.get('visivel', 1))
    return jsonify({'status': 'sucesso'})

@admin_bp.route('/api/menu-admin/reordenar', methods=['POST'])
@login_required
def api_reordenar_menu_admin():
    dados = request.get_json()
    reordenar_menu_admin(dados.get('ids', []))
    return jsonify({'status': 'sucesso'})

# --- ROTAS DE API (PRODUTOS) ---

@admin_bp.route('/api/produtos', methods=['GET'])
@login_required
def listar_produtos_api():
    return jsonify(carregar_dados())

@admin_bp.route('/api/produtos', methods=['POST'])
@login_required
def add_produto():
    nome = request.form.get('nome')
    preco = float(request.form.get('preco', 0))
    categoria = request.form.get('categoria')
    ingredientes = request.form.get('ingredientes', '')
    visivel = int(request.form.get('visivel', 1))

    foto_nova = request.files.get('foto')
    nome_foto = "default.jpg"
    if foto_nova and foto_nova.filename != '':
        filename = secure_filename(foto_nova.filename)
        foto_nova.save(os.path.join(UPLOAD_FOLDER, filename))
        nome_foto = filename

    adicionar_produto(nome, preco, categoria, nome_foto, ingredientes)
    return jsonify({"status": "sucesso"})

@admin_bp.route('/api/produtos/editar/<int:produto_id>', methods=['POST'])
@login_required
def editar_produto(produto_id):
    nome = request.form.get('nome')
    preco = float(request.form.get('preco', 0))
    categoria = request.form.get('categoria')
    ingredientes = request.form.get('ingredientes', '')
    visivel = int(request.form.get('visivel', 1))

    foto_nova = request.files.get('foto')
    nome_foto = None
    if foto_nova and foto_nova.filename != '':
        filename = secure_filename(foto_nova.filename)
        foto_nova.save(os.path.join(UPLOAD_FOLDER, filename))
        nome_foto = filename

    atualizar_produto(produto_id, nome, preco, categoria, nome_foto, ingredientes, visivel)
    return jsonify({"status": "sucesso"})

@admin_bp.route('/api/produtos/<int:produto_id>', methods=['DELETE'])
@login_required
def api_deletar_produto(produto_id):
    deletar_produto(produto_id)
    return jsonify({"status": "sucesso"})

# --- ROTAS DE API (ESTOQUE E INSUMOS COMPARTILHADOS) ---

@admin_bp.route('/api/insumos', methods=['GET'])
@login_required
def api_listar_insumos():
    tipo = request.args.get('tipo')  # ?tipo=bruto ou ?tipo=fabricado
    return jsonify(listar_insumos_db(tipo))

@admin_bp.route('/api/insumos', methods=['POST'])
@login_required
def api_criar_insumo():
    dados = request.get_json()
    novo_id = criar_insumo(
        nome=dados.get('nome'),
        unidade_base=dados.get('unidade_base'),
        estoque_minimo=float(dados.get('estoque_minimo', 0)),
        tipo=dados.get('tipo', 'bruto'),
        validade_padrao=dados.get('validade_padrao')
    )
    return jsonify({"status": "sucesso", "id": novo_id})

@admin_bp.route('/api/insumos/<int:insumo_id>', methods=['PUT'])
@login_required
def api_atualizar_insumo(insumo_id):
    dados = request.get_json()
    atualizar_insumo(insumo_id, dados.get('nome'), dados.get('unidade_base'), float(dados.get('estoque_minimo', 0)), dados.get('validade_padrao'))
    return jsonify({"status": "sucesso"})

@admin_bp.route('/api/insumos/<int:insumo_id>', methods=['DELETE'])
@login_required
def api_deletar_insumo(insumo_id):
    deletar_insumo(insumo_id)
    return jsonify({"status": "sucesso"})

@admin_bp.route('/api/insumos/<int:insumo_id>/lotes', methods=['GET'])
@login_required
def api_lotes_insumo(insumo_id):
    return jsonify(listar_lotes_insumo(insumo_id))

@admin_bp.route('/api/insumos/entrada', methods=['POST'])
@login_required
def api_entrada_estoque():
    dados = request.get_json()
    sucesso = registrar_entrada_lote(
        insumo_id=dados.get('insumo_id'),
        quantidade=float(dados.get('quantidade')),
        fator=float(dados.get('fator_conversao', 1)),
        validade=dados.get('validade'),
        custo=float(dados.get('custo', 0))
    )
    return jsonify({"status": "sucesso" if sucesso else "erro"})

@admin_bp.route('/api/insumos/fabricar', methods=['POST'])
@login_required
def api_fabricar():
    dados = request.get_json()
    resultado = fabricar_lote(
        insumo_fabricado_id=int(dados.get('insumo_fabricado_id')),
        quantidade_produzida=float(dados.get('quantidade')),
        validade=dados.get('validade')
    )
    return jsonify(resultado)

@admin_bp.route('/api/insumos/transformar', methods=['POST'])
@login_required
def api_transformar_insumo():
    dados = request.get_json()
    resultado = transformar_insumos_db(
        pai_id=dados.get('insumo_pai_id'),
        filho_id=dados.get('insumo_filho_id'),
        qtd_pai=float(dados.get('qtd_pai_gasta')),
        qtd_filho=float(dados.get('qtd_filho_gerada'))
    )
    return jsonify(resultado)

@admin_bp.route('/api/receitas/<int:insumo_id>', methods=['GET'])
@login_required
def api_get_receita(insumo_id):
    return jsonify(listar_receita(insumo_id))

@admin_bp.route('/api/receitas/<int:insumo_id>', methods=['POST'])
@login_required
def api_salvar_receita(insumo_id):
    dados = request.get_json()
    salvar_receita(insumo_id, dados.get('ingredientes', []))
    return jsonify({"status": "sucesso"})

@admin_bp.route('/api/produto_insumos/<int:produto_id>', methods=['GET'])
@login_required
def api_get_produto_insumos(produto_id):
    return jsonify(listar_produto_insumos(produto_id))

@admin_bp.route('/api/produto_insumos/<int:produto_id>', methods=['POST'])
@login_required
def api_salvar_produto_insumos(produto_id):
    dados = request.get_json()
    salvar_produto_insumos(produto_id, dados.get('insumos', []))
    return jsonify({"status": "sucesso"})

@admin_bp.route('/api/estoque/alertas', methods=['GET'])
@login_required
def api_alertas_estoque():
    return jsonify(listar_alertas_estoque())

# --- ROTAS DE API (PEDIDOS E TAXAS) ---


@admin_bp.route('/api/listar_pedidos')
@login_required
def listar_pedidos():
    from flask import request as req
    hora_inicio = req.args.get('hora_inicio', type=int)
    dt_inicio   = req.args.get('dt_inicio')   # formato: "2026-04-23 18:00"
    dt_fim      = req.args.get('dt_fim')       # formato: "2026-04-23 22:00"
    pedidos = listar_pedidos_formatados(hora_inicio=hora_inicio, dt_inicio=dt_inicio, dt_fim=dt_fim)
    return jsonify(pedidos)

@admin_bp.route('/api/excluir_pedido/<int:pedido_id>', methods=['DELETE'])
@login_required
def excluir_pedido(pedido_id):
    try:
        conn = conectar()
        conn.execute("DELETE FROM pedidos WHERE id = ?", (pedido_id,))
        conn.commit()
        conn.close()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@admin_bp.route('/api/taxas', methods=['GET', 'POST'])
@login_required
def gerenciar_taxas_api():
    if request.method == 'POST':
        bairro = request.form.get('bairro')
        taxa = float(request.form.get('taxa', 0))
        salvar_taxa(bairro, taxa)
        return jsonify({"status": "sucesso"})
    return jsonify(carregar_taxas())

@admin_bp.route('/api/taxas/<int:taxa_id>', methods=['DELETE'])
@login_required
def deletar_taxa(taxa_id):
    deletar_taxa_db(taxa_id)
    return jsonify({"status": "sucesso"})

@admin_bp.route('/api/pedido_status/<int:pedido_id>', methods=['POST'])
@login_required
def alterar_status_admin(pedido_id):
    dados_req = request.get_json()
    novo_status = dados_req.get('status')
    atualizar_status_pedido(pedido_id, novo_status)
    return jsonify({"success": True})