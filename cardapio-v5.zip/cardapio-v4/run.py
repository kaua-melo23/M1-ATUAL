from flask import Flask, render_template, session, redirect, url_for
import os
import mercadopago
from datetime import timedelta
from dotenv import load_dotenv

# Importando os seus módulos
from database import carregar_dados, carregar_dados_visiveis, init_db, carregar_configuracoes, listar_categorias_ativas
from auth import auth_bp
from routes_admin import admin_bp
from routes_vendas import vendas_bp
from routes_pagamento import pagamento_bp

# 1. Carrega as variáveis do arquivo .env
load_dotenv()

# Inicializa o banco de dados (Cria pastas e arquivos se não existirem)
init_db()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'chave-super-secreta-2026')

# (Configuração do Mercado Pago)
# Busca a chave  salva no .env com o nome MP_ACCESS_TOKEN
mp_token = os.getenv("MP_ACCESS_TOKEN")
sdk = mercadopago.SDK(mp_token)

# --- FUNÇÃO DE DIAGNÓSTICO DE INICIALIZAÇÃO ---
def realizar_testes_iniciais():
    """Valida as conexões essenciais antes de subir o servidor"""
    print("\n" + "="*50)
    print("🚀 DIAGNÓSTICO DE CONEXÃO E CREDENCIAIS")
    print("="*50)

    # A. Validar Mercado Pago
    mp_token = os.getenv("MP_ACCESS_TOKEN")
    if not mp_token:
        print("❌ ERRO: MP_ACCESS_TOKEN não encontrado no .env")
    else:
        try:
            sdk = mercadopago.SDK(mp_token)
            res = sdk.payment().search({'limit': 1})
            status_code = res.get("status")

            if status_code in [200, 201]:
                print(f"✅ MERCADO PAGO: Conexão e Token OK (Status {status_code})")
            elif status_code == 401:
                print("❌ MERCADO PAGO: Token INVÁLIDO (Erro 401 - Unauthorized)")
            else:
                print(f"⚠️ MERCADO PAGO: Resposta inesperada (Status {status_code})")
        except Exception as e:
            print(f"❌ MERCADO PAGO: Falha técnica na conexão: {e}")

    # B. Validar Estrutura de Pastas
    pastas = ['static/uploads', 'database']
    for pasta in pastas:
        if not os.path.exists(pasta):
            os.makedirs(pasta)
            print(f"📁 PASTA: {pasta} criada com sucesso.")

    print("="*50 + "\n")

# --- CONFIGURAÇÕES DE SEGURANÇA E SESSÃO ---
app.config.update(
    SESSION_PERMANENT=True,
    PERMANENT_SESSION_LIFETIME=timedelta(hours=2), # Aumentado para 2 horas para facilitar o uso do Admin
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_REFRESH_EACH_REQUEST=True,
    SESSION_COOKIE_SECURE=False 
)

# Registro dos Blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(vendas_bp)
app.register_blueprint(pagamento_bp)

# --- ROTAS PRINCIPAIS (CLIENTE) ---

@app.route('/')
def index():
    """Página principal do cardápio"""
    produtos = carregar_dados_visiveis()
    configs = carregar_configuracoes()
    categorias = listar_categorias_ativas()
    return render_template('index.html', produtos=produtos, configs=configs, categorias=categorias)

@app.route('/revisar')
def revisar():
    """Nova página de revisão do pedido antes do fechamento"""
    configs = carregar_configuracoes()
    return render_template('revisar.html', configs=configs)

# --- ROTAS ADMINISTRATIVAS (PROTEGIDAS) ---

@app.route('/admin_dashboard')
def admin_page():
    """Verifica login e exibe o dashboard principal"""
    if not session.get('logado'):
        return redirect(url_for('auth_bp.login'))
    return render_template('admin/dashboard.html')

@app.route('/admin/relatorios')
def admin_relatorios():
    """Verifica login e exibe a página de relatórios e filtros"""
    if not session.get('logado'):
        return redirect(url_for('auth_bp.login'))
    return render_template('admin/relatorios.html')

# --- EXECUÇÃO ---

if __name__ == '__main__':
    realizar_testes_iniciais()
    # Debug=True permite que o servidor reinicie sozinho ao salvar arquivos
    app.run(debug=True, port=8080, host='0.0.0.0')