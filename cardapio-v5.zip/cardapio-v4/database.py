import sqlite3
import os
import json
from datetime import datetime

# PADRONIZAÇÃO DO CAMINHO
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_NAME = os.path.join(BASE_DIR, 'database', 'lanchonete.db')
JSON_ANTIGO = os.path.join(BASE_DIR, 'produtos.json')

def conectar():
    os.makedirs(os.path.dirname(DB_NAME), exist_ok=True)
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row  
    return conn

def init_db():
    """Cria as tabelas e migra dados do JSON se necessário"""
    conn = conectar()
    cursor = conn.cursor()
    
    # 1. Tabelas Principais
    cursor.execute('''CREATE TABLE IF NOT EXISTS produtos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        preco REAL NOT NULL,
        categoria TEXT,
        imagem TEXT,
        ingredientes TEXT,
        visivel INTEGER DEFAULT 1
    )''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS taxas_entrega (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bairro TEXT UNIQUE NOT NULL,
        taxa REAL NOT NULL
    )''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS pedidos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        cliente_nome TEXT,
        bairro TEXT,
        endereco TEXT,
        total_produtos REAL,
        taxa_entrega REAL,
        total_geral REAL,
        metodo_pagamento TEXT,
        status TEXT DEFAULT 'Pendente',
        id_pagamento_mp TEXT
    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS itens_pedido (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pedido_id INTEGER,
        produto_nome TEXT, 
        quantidade INTEGER,
        preco_unitario REAL,
        FOREIGN KEY (pedido_id) REFERENCES pedidos (id) ON DELETE CASCADE
    )''')

    # 2. Tabelas de Estoque
    cursor.execute('''CREATE TABLE IF NOT EXISTS insumos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        unidade_base TEXT NOT NULL,
        estoque_minimo REAL DEFAULT 0,
        tipo TEXT DEFAULT 'bruto',
        validade_padrao DATE
    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS lotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        insumo_id INTEGER,
        quantidade_inicial REAL,
        quantidade_atual REAL,
        validade DATE,
        custo_lote REAL,
        data_entrada DATE,
        FOREIGN KEY (insumo_id) REFERENCES insumos (id) ON DELETE CASCADE
    )''')

    # Receitas: ingredientes necessários para fabricar 1 unidade do insumo fabricado
    cursor.execute('''CREATE TABLE IF NOT EXISTS receitas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        insumo_fabricado_id INTEGER NOT NULL,
        insumo_bruto_id INTEGER NOT NULL,
        quantidade REAL NOT NULL,
        FOREIGN KEY (insumo_fabricado_id) REFERENCES insumos (id) ON DELETE CASCADE,
        FOREIGN KEY (insumo_bruto_id) REFERENCES insumos (id)
    )''')

    # Vínculo produto do cardápio → insumo que consome (bruto ou fabricado)
    cursor.execute('''CREATE TABLE IF NOT EXISTS produto_insumo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        produto_id INTEGER NOT NULL,
        insumo_id INTEGER NOT NULL,
        quantidade REAL NOT NULL DEFAULT 1,
        FOREIGN KEY (produto_id) REFERENCES produtos (id) ON DELETE CASCADE,
        FOREIGN KEY (insumo_id) REFERENCES insumos (id) ON DELETE CASCADE
    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS configuracoes (
        chave TEXT PRIMARY KEY,
        valor TEXT
    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS categorias_cliente (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        emoji TEXT DEFAULT '🍽️',
        ordem INTEGER DEFAULT 0,
        ativo INTEGER DEFAULT 1
    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS menu_admin (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        label TEXT NOT NULL,
        url TEXT NOT NULL,
        emoji TEXT DEFAULT '📄',
        ordem INTEGER DEFAULT 0,
        visivel INTEGER DEFAULT 1
    )''')

    # Valores padrão se a tabela estiver vazia
    defaults = [
        ('nome_lanchonete', 'Lanchonete Express'),
        ('slogan', 'O melhor sabor da região'),
        ('cor_primaria', '#dc2626'),
        ('cor_texto_header', '#ffffff'),
        ('logo_url', ''),
        ('hora_abertura', '18:00'),
        ('hora_fechamento', '23:00'),
    ]
    for chave, valor in defaults:
        cursor.execute(
            'INSERT OR IGNORE INTO configuracoes (chave, valor) VALUES (?, ?)',
            (chave, valor)
        )

    # Categorias padrão do cliente
    cursor.execute("SELECT COUNT(*) FROM categorias_cliente")
    if cursor.fetchone()[0] == 0:
        cats_default = [
            ('Lanches', '🍔', 0),
            ('Bebidas', '🥤', 1),
            ('Porções', '🍟', 2),
            ('Sobremesas', '🍨', 3),
        ]
        for nome, emoji, ordem in cats_default:
            cursor.execute(
                'INSERT INTO categorias_cliente (nome, emoji, ordem, ativo) VALUES (?, ?, ?, 1)',
                (nome, emoji, ordem)
            )

    # Itens padrão do menu admin
    cursor.execute("SELECT COUNT(*) FROM menu_admin")
    if cursor.fetchone()[0] == 0:
        menu_default = [
            ('Dashboard',  '/admin',           '📊', 0),
            ('Relatórios', '/admin/relatorios', '📈', 1),
            ('Estoque',    '/admin/estoque',    '📦', 2),
            ('Produtos',   '/admin/produtos',   '🍔', 3),
            ('Pedidos',    '/admin/pedidos',    '🛵', 4),
            ('Taxas',      '/admin/taxas',      '📍', 5),
            ('Aparência',  '/admin/aparencia',  '🎨', 6),
            ('Navegação',  '/admin/navegacao',  '🗂️', 7),
        ]
        for label, url, emoji, ordem in menu_default:
            cursor.execute(
                'INSERT INTO menu_admin (label, url, emoji, ordem, visivel) VALUES (?, ?, ?, ?, 1)',
                (label, url, emoji, ordem)
            )

    conn.commit()

    # Migração: adicionar colunas novas em bancos existentes
    migrações = [
        ("ALTER TABLE produtos ADD COLUMN ingredientes TEXT", None),
        ("ALTER TABLE produtos ADD COLUMN visivel INTEGER DEFAULT 1", "UPDATE produtos SET visivel = 1 WHERE visivel IS NULL"),
        ("ALTER TABLE insumos ADD COLUMN tipo TEXT DEFAULT 'bruto'", "UPDATE insumos SET tipo = 'bruto' WHERE tipo IS NULL"),
        ("ALTER TABLE insumos ADD COLUMN validade_padrao DATE", None),
    ]
    for sql, followup in migrações:
        try:
            cursor.execute(sql)
            if followup:
                cursor.execute(followup)
            conn.commit()
        except Exception:
            pass  # Coluna já existe

    # Migração automática do JSON para SQLite
    cursor.execute("SELECT COUNT(*) FROM produtos")
    if cursor.fetchone()[0] == 0 and os.path.exists(JSON_ANTIGO):
        try:
            with open(JSON_ANTIGO, 'r', encoding='utf-8') as f:
                produtos_json = json.load(f)
                for p in produtos_json:
                    cursor.execute("INSERT INTO produtos (nome, preco, categoria, imagem) VALUES (?, ?, ?, ?)",
                                (p.get('nome'), p.get('preco'), p.get('categoria'), p.get('imagem')))
            conn.commit()
        except Exception as e:
            print(f">>> Erro na migração: {e}")

    conn.close()

# Inicializa o banco ao importar o script
init_db()

# --- FUNÇÕES DE PEDIDOS (UNIFICADAS) ---

def registrar_pedido_completo(p, itens):
    """Registra a capa do pedido e seus respectivos itens em uma única transação."""
    conn = conectar()
    cursor = conn.cursor()
    try:
        cursor.execute('''INSERT INTO pedidos 
            (cliente_nome, bairro, endereco, total_produtos, taxa_entrega, total_geral, metodo_pagamento, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
            (p.get('nome'), p.get('bairro'), p.get('endereco'), p.get('total_itens'), 
            p.get('taxa'), p.get('total_geral'), p.get('metodo'), 'Pendente'))
        
        pedido_id = cursor.lastrowid

        for item in itens:
            cursor.execute('''INSERT INTO itens_pedido 
                (pedido_id, produto_nome, quantidade, preco_unitario) 
                VALUES (?, ?, ?, ?)''',
                (pedido_id, item.get('nome'), item.get('quantidade'), item.get('preco')))
        
        conn.commit()
        return pedido_id
    except Exception as e:
        print(f"Erro ao registrar pedido: {e}")
        conn.rollback()
        return False
    finally:
        conn.close()

def listar_pedidos_formatados(hora_inicio=None, dt_inicio=None, dt_fim=None):
    conn = conectar()
    cursor = conn.cursor()
    if dt_inicio and dt_fim:
        pedidos_rows = cursor.execute(
            "SELECT * FROM pedidos WHERE data_hora >= ? AND data_hora <= ? ORDER BY id DESC",
            (dt_inicio, dt_fim)
        ).fetchall()
    elif dt_inicio:
        pedidos_rows = cursor.execute(
            "SELECT * FROM pedidos WHERE data_hora >= ? ORDER BY id DESC",
            (dt_inicio,)
        ).fetchall()
    elif dt_fim:
        pedidos_rows = cursor.execute(
            "SELECT * FROM pedidos WHERE data_hora <= ? ORDER BY id DESC",
            (dt_fim,)
        ).fetchall()
    elif hora_inicio is not None:
        pedidos_rows = cursor.execute(
            "SELECT * FROM pedidos WHERE CAST(strftime('%H', data_hora) AS INTEGER) >= ? ORDER BY id DESC",
            (hora_inicio,)
        ).fetchall()
    else:
        pedidos_rows = cursor.execute('SELECT * FROM pedidos ORDER BY id DESC').fetchall()
    pedidos_final = []
    for p_row in pedidos_rows:
        p = dict(p_row)
        itens_rows = cursor.execute('SELECT produto_nome, quantidade, preco_unitario FROM itens_pedido WHERE pedido_id = ?', (p['id'],)).fetchall()
        p['itens'] = [{'produto_nome': i['produto_nome'], 'quantidade': i['quantidade'], 'preco_unitario': i['preco_unitario']} for i in itens_rows]
        p['data'] = p['data_hora']
        p['total'] = p['total_geral']
        p['metodo'] = p['metodo_pagamento']
        pedidos_final.append(p)
    conn.close()
    return pedidos_final

def atualizar_status_pedido(pedido_id, novo_status):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("UPDATE pedidos SET status = ? WHERE id = ?", (novo_status, pedido_id))
    conn.commit()
    conn.close()

# --- FUNÇÕES DE ESTOQUE ---

def listar_insumos_db(tipo=None):
    conn = conectar()
    cursor = conn.cursor()
    sql = '''
        SELECT i.*,
        COALESCE(SUM(CASE WHEN l.validade >= date('now') THEN l.quantidade_atual ELSE 0 END), 0) as total_estoque,
        MIN(CASE WHEN l.validade >= date('now') AND l.quantidade_atual > 0 THEN l.validade END) as proxima_validade
        FROM insumos i
        LEFT JOIN lotes l ON i.id = l.insumo_id
    '''
    if tipo:
        sql += " WHERE i.tipo = ?"
        cursor.execute(sql + " GROUP BY i.id ORDER BY i.nome", (tipo,))
    else:
        cursor.execute(sql + " GROUP BY i.id ORDER BY i.nome")
    insumos = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return insumos

def criar_insumo(nome, unidade_base, estoque_minimo, tipo='bruto', validade_padrao=None):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO insumos (nome, unidade_base, estoque_minimo, tipo, validade_padrao) VALUES (?, ?, ?, ?, ?)",
        (nome, unidade_base, estoque_minimo, tipo, validade_padrao)
    )
    conn.commit()
    novo_id = cursor.lastrowid
    conn.close()
    return novo_id

def atualizar_insumo(insumo_id, nome, unidade_base, estoque_minimo, validade_padrao=None):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE insumos SET nome=?, unidade_base=?, estoque_minimo=?, validade_padrao=? WHERE id=?",
        (nome, unidade_base, estoque_minimo, validade_padrao, insumo_id)
    )
    conn.commit()
    conn.close()

def deletar_insumo(insumo_id):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM insumos WHERE id=?", (insumo_id,))
    conn.commit()
    conn.close()

def listar_lotes_insumo(insumo_id):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT *, 
        CASE WHEN validade < date('now') THEN 1 ELSE 0 END as vencido,
        CASE WHEN validade <= date('now', '+7 days') AND validade >= date('now') THEN 1 ELSE 0 END as vence_em_breve
        FROM lotes WHERE insumo_id = ? ORDER BY validade ASC
    ''', (insumo_id,))
    lotes = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return lotes

# --- RECEITAS (Insumos Fabricados) ---

def salvar_receita(insumo_fabricado_id, ingredientes):
    """ingredientes: lista de {insumo_bruto_id, quantidade}"""
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM receitas WHERE insumo_fabricado_id=?", (insumo_fabricado_id,))
    for ing in ingredientes:
        cursor.execute(
            "INSERT INTO receitas (insumo_fabricado_id, insumo_bruto_id, quantidade) VALUES (?, ?, ?)",
            (insumo_fabricado_id, ing['insumo_bruto_id'], ing['quantidade'])
        )
    conn.commit()
    conn.close()

def listar_receita(insumo_fabricado_id):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT r.*, i.nome as nome_bruto, i.unidade_base
        FROM receitas r
        JOIN insumos i ON r.insumo_bruto_id = i.id
        WHERE r.insumo_fabricado_id = ?
    ''', (insumo_fabricado_id,))
    receita = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return receita

def fabricar_lote(insumo_fabricado_id, quantidade_produzida, validade):
    """Desconta brutos conforme receita e gera lote do fabricado."""
    conn = conectar()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            SELECT r.insumo_bruto_id, r.quantidade * ? as qtd_necessaria, i.nome
            FROM receitas r
            JOIN insumos i ON r.insumo_bruto_id = i.id
            WHERE r.insumo_fabricado_id = ?
        ''', (quantidade_produzida, insumo_fabricado_id))
        ingredientes = cursor.fetchall()

        if not ingredientes:
            return {"status": "erro", "msg": "Este insumo não tem receita cadastrada."}

        # Verifica estoque suficiente antes de descontar
        for ing in ingredientes:
            cursor.execute('''
                SELECT COALESCE(SUM(quantidade_atual), 0) as total
                FROM lotes WHERE insumo_id = ? AND validade >= date('now')
            ''', (ing['insumo_bruto_id'],))
            disponivel = cursor.fetchone()['total']
            if disponivel < ing['qtd_necessaria']:
                return {"status": "erro", "msg": f"Estoque insuficiente de '{ing['nome']}'. Necessário: {ing['qtd_necessaria']}, Disponível: {round(disponivel, 2)}"}

        # Desconta os brutos (PVPS)
        for ing in ingredientes:
            restante = ing['qtd_necessaria']
            cursor.execute('''
                SELECT id, quantidade_atual FROM lotes
                WHERE insumo_id = ? AND quantidade_atual > 0 AND validade >= date('now')
                ORDER BY validade ASC
            ''', (ing['insumo_bruto_id'],))
            lotes = cursor.fetchall()
            for lote in lotes:
                if restante <= 0:
                    break
                desconto = min(restante, lote['quantidade_atual'])
                cursor.execute("UPDATE lotes SET quantidade_atual = quantidade_atual - ? WHERE id=?",
                               (desconto, lote['id']))
                restante -= desconto

        # Cria lote do fabricado
        cursor.execute('''
            INSERT INTO lotes (insumo_id, quantidade_inicial, quantidade_atual, validade, data_entrada)
            VALUES (?, ?, ?, ?, date('now'))
        ''', (insumo_fabricado_id, quantidade_produzida, quantidade_produzida, validade))

        conn.commit()
        return {"status": "sucesso", "msg": f"{quantidade_produzida} unidade(s) fabricada(s) com sucesso!"}
    except Exception as e:
        conn.rollback()
        return {"status": "erro", "msg": str(e)}
    finally:
        conn.close()

# --- VÍNCULO PRODUTO → INSUMO ---

def salvar_produto_insumos(produto_id, insumos):
    """insumos: lista de {insumo_id, quantidade}"""
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM produto_insumo WHERE produto_id=?", (produto_id,))
    for item in insumos:
        cursor.execute(
            "INSERT INTO produto_insumo (produto_id, insumo_id, quantidade) VALUES (?, ?, ?)",
            (produto_id, item['insumo_id'], item['quantidade'])
        )
    conn.commit()
    conn.close()

def listar_produto_insumos(produto_id):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT pi.*, i.nome as nome_insumo, i.unidade_base, i.tipo
        FROM produto_insumo pi
        JOIN insumos i ON pi.insumo_id = i.id
        WHERE pi.produto_id = ?
    ''', (produto_id,))
    result = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return result

def listar_alertas_estoque():
    """Retorna insumos abaixo do estoque mínimo."""
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT i.nome, i.unidade_base, i.tipo, i.estoque_minimo,
        COALESCE(SUM(CASE WHEN l.validade >= date('now') THEN l.quantidade_atual ELSE 0 END), 0) as total_estoque
        FROM insumos i
        LEFT JOIN lotes l ON i.id = l.insumo_id
        GROUP BY i.id
        HAVING total_estoque <= i.estoque_minimo AND i.estoque_minimo > 0
        ORDER BY (total_estoque / NULLIF(i.estoque_minimo, 0)) ASC
    ''')
    alertas = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return alertas



def registrar_entrada_lote(insumo_id, quantidade, fator, validade, custo):
    quantidade_final = float(quantidade) * float(fator)
    try:
        conn = conectar()
        conn.execute('''
            INSERT INTO lotes (insumo_id, quantidade_inicial, quantidade_atual, validade, custo_lote, data_entrada)
            VALUES (?, ?, ?, ?, ?, date('now'))
        ''', (insumo_id, quantidade_final, quantidade_final, validade, custo))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Erro ao registrar lote: {e}")
        return False

def baixar_estoque_por_produto(nome_produto, quantidade_vendida):
    """Abate insumos vinculados ao produto. Segue PVPS."""
    conn = conectar()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id FROM produtos WHERE nome = ?", (nome_produto,))
        produto = cursor.fetchone()
        if not produto:
            return

        produto_id = produto['id']
        cursor.execute('''
            SELECT pi.insumo_id, pi.quantidade * ? as qtd_descontar
            FROM produto_insumo pi WHERE pi.produto_id = ?
        ''', (quantidade_vendida, produto_id))
        vinculos = cursor.fetchall()

        # Fallback legado: tenta pelo nome do insumo igual ao produto
        if not vinculos:
            cursor.execute("SELECT id FROM insumos WHERE nome = ?", (nome_produto,))
            insumo = cursor.fetchone()
            if insumo:
                vinculos = [{'insumo_id': insumo['id'], 'qtd_descontar': quantidade_vendida}]

        for v in vinculos:
            restante = v['qtd_descontar']
            cursor.execute('''
                SELECT id, quantidade_atual FROM lotes
                WHERE insumo_id = ? AND quantidade_atual > 0 AND validade >= date('now')
                ORDER BY validade ASC
            ''', (v['insumo_id'],))
            for lote in cursor.fetchall():
                if restante <= 0:
                    break
                desconto = min(restante, lote['quantidade_atual'])
                cursor.execute("UPDATE lotes SET quantidade_atual = quantidade_atual - ? WHERE id=?",
                               (desconto, lote['id']))
                restante -= desconto

        conn.commit()
    except Exception as e:
        print(f"Erro ao baixar estoque: {e}")
    finally:
        conn.close()

def transformar_insumos_db(pai_id, filho_id, qtd_pai, qtd_filho):
    conn = conectar()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            SELECT id, quantidade_atual, validade FROM lotes 
            WHERE insumo_id = ? AND quantidade_atual > 0 AND validade >= date('now')
            ORDER BY validade ASC
        ''', (pai_id,))
        lotes_ativos = cursor.fetchall()

        if not lotes_ativos:
            return {"status": "erro", "msg": "Sem estoque disponível ou vencido"}

        lote_id, atual, validade_pai = lotes_ativos[0]
        if atual < qtd_pai:
            return {"status": "erro", "msg": "Quantidade insuficiente no lote atual"}

        cursor.execute("UPDATE lotes SET quantidade_atual = quantidade_atual - ? WHERE id = ?", (qtd_pai, lote_id))

        cursor.execute('''
            INSERT INTO lotes (insumo_id, quantidade_inicial, quantidade_atual, validade, data_entrada)
            VALUES (?, ?, ?, ?, date('now'))
        ''', (filho_id, qtd_filho, qtd_filho, validade_pai))

        conn.commit()
        return {"status": "sucesso", "msg": "Transformação concluída"}
    except Exception as e:
        conn.rollback()
        return {"status": "erro", "msg": str(e)}
    finally:
        conn.close()

# --- FUNÇÕES DE PRODUTOS E TAXAS ---

def carregar_dados():
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM produtos ORDER BY id ASC")
    dados = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return dados

def carregar_dados_visiveis():
    """Retorna apenas produtos visíveis para o cardápio público"""
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM produtos WHERE visivel = 1 ORDER BY id ASC")
    dados = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return dados

def salvar_dados(dados_lista):
    conn = conectar()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM produtos")
        for p in dados_lista:
            cursor.execute(
                "INSERT INTO produtos (nome, preco, categoria, imagem, ingredientes, visivel) VALUES (?, ?, ?, ?, ?, ?)",
                (p.get('nome'), p.get('preco'), p.get('categoria'), p.get('imagem'), p.get('ingredientes'), p.get('visivel', 1))
            )
        conn.commit()
    except:
        conn.rollback()
    finally:
        conn.close()

def adicionar_produto(nome, preco, categoria, imagem, ingredientes):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO produtos (nome, preco, categoria, imagem, ingredientes, visivel) VALUES (?, ?, ?, ?, ?, 1)",
        (nome, preco, categoria, imagem, ingredientes)
    )
    conn.commit()
    novo_id = cursor.lastrowid
    conn.close()
    return novo_id

def atualizar_produto(produto_id, nome, preco, categoria, imagem, ingredientes, visivel):
    conn = conectar()
    cursor = conn.cursor()
    if imagem:
        cursor.execute(
            "UPDATE produtos SET nome=?, preco=?, categoria=?, imagem=?, ingredientes=?, visivel=? WHERE id=?",
            (nome, preco, categoria, imagem, ingredientes, visivel, produto_id)
        )
    else:
        cursor.execute(
            "UPDATE produtos SET nome=?, preco=?, categoria=?, ingredientes=?, visivel=? WHERE id=?",
            (nome, preco, categoria, ingredientes, visivel, produto_id)
        )
    conn.commit()
    conn.close()

def deletar_produto(produto_id):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM produtos WHERE id = ?", (produto_id,))
    conn.commit()
    conn.close()

def carregar_taxas():
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM taxas_entrega ORDER BY bairro ASC")
    taxas = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return taxas

def salvar_taxa(bairro, valor):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO taxas_entrega (bairro, taxa) VALUES (?, ?)", (bairro, valor))
    conn.commit()
    conn.close()
    
def deletar_taxa_db(taxa_id):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM taxas_entrega WHERE id = ?", (taxa_id,))
    conn.commit()
    conn.close()

# --- FUNÇÕES DE CONFIGURAÇÕES DE APARÊNCIA ---

def carregar_configuracoes():
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT chave, valor FROM configuracoes")
    configs = {row['chave']: row['valor'] for row in cursor.fetchall()}
    conn.close()
    return configs

def salvar_configuracoes(dados: dict):
    conn = conectar()
    cursor = conn.cursor()
    for chave, valor in dados.items():
        cursor.execute(
            'INSERT OR REPLACE INTO configuracoes (chave, valor) VALUES (?, ?)',
            (chave, valor)
        )
    conn.commit()
    conn.close()

# --- FUNÇÕES DE CATEGORIAS DO CLIENTE ---

def listar_categorias():
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM categorias_cliente ORDER BY ordem ASC")
    cats = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return cats

def listar_categorias_ativas():
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM categorias_cliente WHERE ativo=1 ORDER BY ordem ASC")
    cats = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return cats

def salvar_categoria(nome, emoji):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT COALESCE(MAX(ordem),0)+1 FROM categorias_cliente")
    proxima = cursor.fetchone()[0]
    cursor.execute(
        "INSERT INTO categorias_cliente (nome, emoji, ordem, ativo) VALUES (?, ?, ?, 1)",
        (nome, emoji, proxima)
    )
    conn.commit()
    conn.close()

def atualizar_categoria(cat_id, nome, emoji, ativo):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE categorias_cliente SET nome=?, emoji=?, ativo=? WHERE id=?",
        (nome, emoji, ativo, cat_id)
    )
    conn.commit()
    conn.close()

def deletar_categoria(cat_id):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM categorias_cliente WHERE id=?", (cat_id,))
    conn.commit()
    conn.close()

def reordenar_categorias(ids_ordenados: list):
    conn = conectar()
    cursor = conn.cursor()
    for i, cat_id in enumerate(ids_ordenados):
        cursor.execute("UPDATE categorias_cliente SET ordem=? WHERE id=?", (i, cat_id))
    conn.commit()
    conn.close()

# --- FUNÇÕES DE MENU ADMIN ---

def listar_menu_admin():
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM menu_admin ORDER BY ordem ASC")
    itens = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return itens

def listar_menu_admin_visivel():
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM menu_admin WHERE visivel=1 ORDER BY ordem ASC")
    itens = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return itens

def atualizar_item_menu(item_id, label, emoji, visivel):
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE menu_admin SET label=?, emoji=?, visivel=? WHERE id=?",
        (label, emoji, visivel, item_id)
    )
    conn.commit()
    conn.close()

def reordenar_menu_admin(ids_ordenados: list):
    conn = conectar()
    cursor = conn.cursor()
    for i, item_id in enumerate(ids_ordenados):
        cursor.execute("UPDATE menu_admin SET ordem=? WHERE id=?", (i, item_id))
    conn.commit()
    conn.close()