from flask import Blueprint, render_template, request, redirect, url_for, session
import os

auth_bp = Blueprint('auth_bp', __name__)

ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "1234")

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    erro = None
    if request.method == 'POST':
        usuario = request.form.get('username')
        senha = request.form.get('password')
        
        if usuario == ADMIN_USER and senha == ADMIN_PASSWORD:
            session['logado'] = True
            return redirect(url_for('admin_page'))
        else:
            erro = "Usuário ou senha incorretos."
    
    return render_template('login.html', erro=erro)

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth_bp.login'))