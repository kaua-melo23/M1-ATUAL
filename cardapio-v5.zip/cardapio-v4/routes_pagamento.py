import os
import mercadopago
from flask import Blueprint, request, jsonify
from dotenv import load_dotenv

# Importamos as funções do seu database.py
from database import (conectar, atualizar_status_pedido, baixar_estoque_por_produto)

load_dotenv()

pagamento_bp = Blueprint('pagamento_bp', __name__)

# Configuração Mercado Pago
MP_ACCESS_TOKEN = os.getenv("MP_ACCESS_TOKEN")
sdk = mercadopago.SDK(MP_ACCESS_TOKEN)

def enviar_whatsapp_sucesso(pedido_id):
    """
    Simulação do disparo de WhatsApp. 
    Integre aqui com sua API de mensagens.
    """
    print(f"✅ PAGAMENTO CONFIRMADO: Enviando pedido #{pedido_id} para o WhatsApp do restaurante!")

@pagamento_bp.route('/api/pagamento/gerar_pix', methods=['POST'])
def gerar_pix():
    dados_pedido = request.get_json()
    
    if not dados_pedido or 'total' not in dados_pedido:
        return jsonify({"erro": "Dados do pedido inválidos"}), 400

    pedido_id_local = dados_pedido.get('id')

    payment_data = {
        "transaction_amount": float(dados_pedido['total']),
        "description": f"Pedido #{pedido_id_local} - Lanchonete",
        "payment_method_id": "pix",
        "payer": {
            "email": "cliente@email.com",
            "first_name": "Cliente"
        }
    }

    try:
        payment_response = sdk.payment().create(payment_data)
        payment = payment_response["response"]

        if "point_of_interaction" in payment:
            info_pix = payment["point_of_interaction"]["transaction_data"]
            id_mercado_pago = str(payment["id"])

            # ATUALIZA O BANCO DE DADOS SQLITE (Não usamos mais o JSON)
            conn = conectar()
            conn.execute('''
                UPDATE pedidos 
                SET id_pagamento_mp = ?, status = 'Aguardando Pagamento' 
                WHERE id = ?
            ''', (id_mercado_pago, pedido_id_local))
            conn.commit()
            conn.close()

            return jsonify({
                "status": "pending",
                "id_pagamento_mp": id_mercado_pago,
                "pix_copia_cola": info_pix["qr_code"],
                "qr_code_img": info_pix["qr_code_base64"]
            })
        
        return jsonify({"erro": "Erro ao gerar PIX"}), 400

    except Exception as e:
        return jsonify({"erro": str(e)}), 500

@pagamento_bp.route('/webhook/mercadopago', methods=['POST'])
def webhook_mercadopago():
    """
    Aqui é onde a mágica acontece: Só libera o pedido após o pagamento.
    """
    # Captura o ID do pagamento enviado pelo Mercado Pago
    id_recurso = request.args.get('data.id') or request.get_json().get('data', {}).get('id')
    tipo_recurso = request.args.get('type') or request.get_json().get('type')

    if tipo_recurso == "payment" and id_recurso:
        try:
            # Consulta o status real no Mercado Pago
            payment_info = sdk.payment().get(id_recurso)
            status_real = payment_info["response"]["status"]

            if status_real == "approved":
                conn = conectar()
                # 1. Localiza o pedido no Banco de Dados pelo ID do Mercado Pago
                pedido = conn.execute('SELECT id, status FROM pedidos WHERE id_pagamento_mp = ?', 
                                    (str(id_recurso),)).fetchone()
                
                if pedido and pedido['status'] != 'Pago':
                    pedido_id = pedido['id']
                    
                    # 2. Busca os itens para baixar o estoque (Baseado no seu database.py)
                    itens = conn.execute('SELECT produto_nome, quantidade FROM itens_pedido WHERE pedido_id = ?', 
                                    (pedido_id,)).fetchall()
                    
                    # 3. Baixa o estoque
                    for item in itens:
                        baixar_estoque_por_produto(item['produto_nome'], item['quantidade'])
                    
                    # 4. Atualiza o status para Pago
                    atualizar_status_pedido(pedido_id, 'Pago')
                    
                    # 5. DISPARA PARA O WHATSAPP
                    enviar_whatsapp_sucesso(pedido_id)
                
                conn.close()

        except Exception as e:
            print(f"Erro no processamento do Webhook: {e}")

    return jsonify({"status": "recebido"}), 200